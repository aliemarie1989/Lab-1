your_age = int(input("How old are you?: "))
if your_age <= 16:
  print("Perfect I want to find out about books that children like.")
  your_book_choice=input("What is your favourite book?: ")
  print ("Good choice, I love",your_book_choice,"too!")
else:
  print("Thanks for helping - but only children can answer this survey.")

#Use elif statements to modify the code so that different age ranges of children get different questions.
#For 6 and under it asks about their favourite picture books
#For 6-10 it asks their favourite story book
#For 10-16 it asks for t